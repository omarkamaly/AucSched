package com.example.aucsched;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private Spinner semesternumber;
    private Spinner major;
    private Spinner intending;
    private Spinner plan;
    Button mOrder;
    String [] list1;
    String [] list2;
    boolean[] checkedItems;
    ArrayList<Integer> mUserItems= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Context context = getApplicationContext();
//        Resources resources = context.getResources();
        semesternumber= findViewById(R.id.semesternumber);
        major =findViewById(R.id.major);
        intending=findViewById(R.id.intending);
        plan= findViewById(R.id.plan);

       ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this, R.array.Semester, android.R.layout.simple_spinner_item);
       adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       semesternumber.setAdapter(adapter);
        ArrayAdapter<CharSequence> adapter1= ArrayAdapter.createFromResource(this, R.array.Major, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        major.setAdapter(adapter1);
        ArrayAdapter<CharSequence> adapter2= ArrayAdapter.createFromResource(this, R.array.intending, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        intending.setAdapter(adapter2);
        ArrayAdapter<CharSequence> adapter3= ArrayAdapter.createFromResource(this, R.array.plan, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        plan.setAdapter(adapter3);
        list1=getResources().getStringArray(R.array.CE);
        checkedItems= new boolean[list1.length];
        mOrder= (Button)findViewById(R.id.button);
//        list2=getResources().getStringArray(R.array.Cs);
//        checkedItems= new boolean[list2.length];
        mOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                mBuilder.setTitle(" Available Courses");
                mBuilder.setMultiChoiceItems(list1, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int position, boolean isChecked) {
                        if (isChecked) {
                            if (!mUserItems.contains(position)) {
                                mUserItems.add(position);
                            }
                        } else if (mUserItems.contains(position)){
                            mUserItems.remove(position);
                        }
                    }
                });
                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String item = " ";
                        for (int i = 0; i < mUserItems.size(); i++) {
                            item = item + list1[mUserItems.get(i)];
                            if (i!=mUserItems.size()-1)
                            {
                                item= item+", ";
                            }
                        }
                    }
                });

            }
        });
    }
}


//semesternumber.setOnItemClickListener(new AdapterView.OnItemSelectedListener() {
//    @Override
//    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//        String semester2 =  semesternumber.getSelectedItem(). toString();
//        if (semester2.equals("Semester")){
//            semester1.setText("you choose"+semesternumber);
//    }
//    }
//
//    @Override
//    public void onNothingSelected(AdapterView<?> parent) {
//
//    }
//
//});
